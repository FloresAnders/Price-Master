TIMEMASTER HERRAMIENTAS 1.0.12
================================

Esta extensión reúne CambioTab, división de efectivo, movimiento entre medios
de pago, cierre automático del modal de impresión de Contica, SumaTiempos,
ingreso de venta con Ctrl+Enter y MoverEnter en una sola instalación. Las tres extensiones originales permanecen
como respaldo, pero deben estar desactivadas mientras se usa esta versión para
evitar acciones duplicadas.

INSTALACIÓN EN EDGE O CHROME
----------------------------
1. Extraiga TimeMasterHerramientas.zip, si va a instalar desde el ZIP.
2. Abra edge://extensions o chrome://extensions.
3. Active el modo de desarrollador.
4. Pulse "Cargar descomprimida" y seleccione la carpeta TimeMasterHerramientas.
5. Desactive CambioTab, SumaTiempos y moverenter antiguas.
6. Recargue las pestañas abiertas de Contica y Gente Crystal.

CONTROLES Y VALORES INICIALES
-----------------------------
- CambioTab en Contica: activado.
- Cierre del modal de impresión en Contica: desactivado.
- División de efectivo en Contica: desactivada.
- Movimiento entre medios de pago en Contica: desactivado.
- SumaTiempos en Gente Crystal: activado.
- Ingresar venta con Ctrl+Enter en Gente Crystal: desactivado.
- Impresión automática en Gente Crystal: desactivada.
- Resaltado de líneas del tiquete en Gente Crystal: desactivado.
- Formato completo de impresión BCR en about:blank: desactivado.

Pulse el icono de la extensión para cambiar cada función por separado. Los
cambios se aplican inmediatamente a las páginas compatibles ya abiertas.

CAMBIOTAB EN CONTICA
--------------------
Sitio: https://contica.app/app/modules/punto_de_venta/*

- Ctrl+Alt+Flecha derecha: pestaña disponible siguiente.
- Ctrl+Alt+Flecha izquierda: pestaña disponible anterior.
- Ctrl+Alt+1 a Ctrl+Alt+7: abrir directamente esa pestaña.
- También acepta los números del teclado numérico.

CIERRE DEL MODAL DE IMPRESIÓN EN CONTICA
----------------------------------------
Sitio: https://contica.app/app/modules/punto_de_venta/*

Al activarlo, puede definir desde el popup un tiempo entero de 1 segundo en
adelante; el valor inicial es 5 segundos. La extensión detecta cada apertura de
#printInvoice, espera el tiempo configurado y pulsa una sola vez el botón X / ESC
del mismo modal. La espera se cancela si el modal se cierra antes o si la
herramienta se desactiva.

Mientras transcurre la espera, muestra un recordatorio lateral con el mensaje
inicial "Recuerde consultar si desea la factura impresa". El texto puede
cambiarse desde el popup de la extensión y se guarda para las siguientes ventas.

DIVISIÓN DE EFECTIVO EN CONTICA
-------------------------------
Sitio: https://contica.app/app/modules/punto_de_venta/*

Al activarla, permite escribir una división directamente en los campos de
efectivo en dólares o colones. Acepta divisores del 2 al 5; por ejemplo,
7500/2 se reemplaza por 3750 en el mismo campo. Los resultados no exactos se
redondean a dos decimales. Los demás campos de pago no se modifican.

MOVER MONTO ENTRE MEDIOS DE PAGO EN CONTICA
--------------------------------------------
Sitio: https://contica.app/app/modules/punto_de_venta/*

Al activarlo, pulse E, T o S dentro de un campo de pago para mover su monto a
efectivo, tarjeta o SINPE, respectivamente, conservando la moneda. El destino
reemplaza cualquier monto anterior. Si el origen está vacío, solamente mueve
el cursor al campo de destino.

SUMATIEMPOS EN GENTE CRYSTAL
----------------------------
Sitio: https://gentecrystal.net/controllers/sales/SalesController.php*

El panel muestra:

  total general = total del tiquete
                + cantidad de números × (monto principal + monto compañero)

El monto compañero solo se suma cuando su control está visible y habilitado.

INGRESAR VENTA CON CTRL+ENTER EN GENTE CRYSTAL
----------------------------------------------
Sitio: https://gentecrystal.net/controllers/sales/SalesController.php*

Al activarlo, Ctrl+Enter o Ctrl+Enter del teclado numérico pulsa una sola vez
el botón #btn-submit-sale. El atajo no actúa cuando el botón no existe, está
oculto o deshabilitado.

IMPRESIÓN AUTOMÁTICA EN GENTE CRYSTAL
-------------------------------------
Al activarla, la extensión pulsa una sola vez el botón de impresión web por
cada apertura del diálogo de venta completada. Esto abre o envía la impresión
según la configuración del navegador; no equivale por sí solo a aceptar el
diálogo nativo de impresión.

Para impresión totalmente desatendida, Edge o Chrome debe iniciarse con la
opción --kiosk-printing y la impresora correcta debe estar configurada. Use esa
opción únicamente en un equipo controlado destinado a caja.

RESALTAR LÍNEAS DEL TIQUETE EN GENTE CRYSTAL
--------------------------------------------
Sitios:
- https://gentecrystal.net/controllers/sales/SalesController.php*
- https://gentecrystal.net/print_pagos.php*

Al activarlo, detecta por separado el código con formato 44559-2204-61486297,
la línea de fecha con formato Fecha: 04/11/2026 y la línea siguiente con el
nombre del sorteo, por ejemplo LA ANGUILA MAÑANA. Cada línea tiene sus propios
controles de tamaño (10 a 72 px), grosor (600 a 900) y tipo de letra. Los
valores iniciales son 22 px, grosor 700 y el tipo de letra original. Pulse
Guardar configuración para persistir juntos el interruptor y los nueve valores;
el popup confirma con el mensaje "Guardado". Al desactivar el interruptor se
ocultan los controles y la impresión queda sin cambios. Restablecer valores
devuelve las tres líneas a 22 px, grosor 700 y letra original; luego pulse
Guardar configuración para confirmar el cambio.

FORMATO COMPLETO DE IMPRESIÓN BCR
---------------------------------
Sitio iniciador: https://www.bcrcorresponsal.bancobcr.com/*

Al activarlo, aplica una misma fuente a todo el comprobante generado dentro de
about:blank. Los valores iniciales son 21 px, grosor 900 y Verdana. El rango de
Tamaño permitido: 10 a 72 px. Pulse Guardar configuración para persistir
juntos el interruptor y los tres valores. Restablecer valores vuelve a
21 px, grosor 900 y Verdana sin escribir en storage hasta pulsar Guardar.

ACTUALIZACIONES
---------------
Después de reemplazar archivos o recargar la extensión desde la página de
extensiones, recargue también las pestañas de Contica y Gente Crystal.

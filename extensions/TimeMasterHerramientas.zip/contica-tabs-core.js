(function initializeConticaTabsCore(root, factory) {
  const api = factory();
  root.TimeMasterHerramientasConticaTabs = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function buildConticaTabsCore() {
  "use strict";

  const EXTRA_ATTRIBUTE = "data-tmh-contica-tab-extra";
  const HIDDEN_ATTRIBUTE = "data-tmh-contica-tab-native-hidden";
  const MAX_EXTRA_TABS = 12;

  function normalizeConfig(raw = {}) {
    return {
      enabled: raw?.enabled === true,
      count:
        Number.isInteger(raw?.count) &&
        raw.count >= 0 &&
        raw.count <= MAX_EXTRA_TABS
          ? raw.count
          : 3,
    };
  }

  function createVisibleTabsController({ documentRef, windowRef }) {
    let config = normalizeConfig();
    let pending = false;
    let started = false;
    let observer = null;
    let status = { found: false, shown: 0, limit: 0 };
    let styleElement = null;

    const nativeId = (link) => {
      const explicit = Number(link.getAttribute("data-tab"));
      if (Number.isInteger(explicit) && explicit >= 1 && explicit <= 99) {
        return explicit;
      }
      const label = link.textContent.trim().replace(/^Factura\s*/i, "").trim();
      return /^\d{1,2}$/.test(label) ? Number(label) : 0;
    };

    const nativeLinks = (root) =>
      [...root.children]
        .filter((item) => !item.hasAttribute(EXTRA_ATTRIBUTE))
        .map((item) =>
          [...item.children].find(
            (candidate) =>
              candidate.matches("a,button") && nativeId(candidate) > 0,
          ),
        )
        .filter(Boolean);

    const extraItems = (root) => [
      ...root.querySelectorAll(`:scope > li[${EXTRA_ATTRIBUTE}]`),
    ];

    const clearExtraItems = (root) => {
      for (const item of extraItems(root)) item.remove();
    };

    const isVisible = (element) =>
      Boolean(
        element &&
          element.getClientRects().length &&
          windowRef.getComputedStyle(element).visibility !== "hidden",
      );

    function apply() {
      pending = false;
      const root = documentRef.querySelector("#tabs");
      const select = root?.querySelector("#extra-tabs");
      status = { found: Boolean(select), shown: 0, limit: 0 };
      if (!root || !select) return status;

      const drop = select.closest("#tabs > li");
      const parent = root.parentElement;
      const nativeItems = [...root.children].filter(
        (item) => !item.hasAttribute(EXTRA_ATTRIBUTE),
      );
      if (!drop || !parent || !isVisible(drop) || !isVisible(root)) {
        clearExtraItems(root);
        for (const item of nativeItems) item.removeAttribute(HIDDEN_ATTRIBUTE);
        return status;
      }

      const original = nativeLinks(root);
      const nativeExtra = original.filter((link) => nativeId(link) > 7);
      const nativeById = new Map(
        nativeExtra.map((link) => [nativeId(link), link]),
      );
      const optionById = new Map(
        [...select.options]
          .filter((option) => !option.disabled && Number(option.value) > 7)
          .map((option) => [Number(option.value), option]),
      );
      const options = [...new Set([...optionById.keys(), ...nativeById.keys()])]
        .sort((left, right) => left - right)
        .map((id) => ({
          value: String(id),
          option: optionById.get(id),
          native: nativeById.get(id),
        }));
      const activeNative = nativeExtra.find((link) =>
        link.parentElement.classList.contains("active"),
      );
      for (const link of nativeExtra) {
        link.parentElement.toggleAttribute(
          HIDDEN_ATTRIBUTE,
          config.enabled && config.count > 0,
        );
      }

      const rootRect = root.getBoundingClientRect();
      const actions = parent.querySelector(".pv-nav-actions");
      const indicator = parent.querySelector(".pv-nav-status");
      const actionsRect = actions?.getBoundingClientRect();
      const indicatorRect = indicator?.getBoundingClientRect();
      const right = Math.min(
        windowRef.innerWidth - 12,
        actionsRect && actionsRect.width > 0 && actionsRect.left > rootRect.left
          ? actionsRect.left
          : windowRef.innerWidth - 12,
      );
      const reserve = (indicatorRect?.width || 0) + 28;
      const nativeWidth = nativeItems.filter(isVisible).reduce((sum, item) => {
        const itemStyle = windowRef.getComputedStyle(item);
        return (
          sum +
          item.getBoundingClientRect().width +
          (Number.parseFloat(itemStyle.marginLeft) || 0) +
          (Number.parseFloat(itemStyle.marginRight) || 0)
        );
      }, 0);
      const sample = original.find((link) => nativeId(link) === 7)?.parentElement;
      const unit = Math.max(
        34,
        Math.ceil(sample?.getBoundingClientRect().width || 34) + 8,
      );
      const limit = Math.max(
        0,
        Math.min(
          MAX_EXTRA_TABS,
          options.length,
          Math.floor((right - rootRect.left - nativeWidth - reserve) / unit),
        ),
      );
      status.limit = limit;
      const wanted = config.enabled ? Math.min(limit, config.count) : 0;
      const selected = select.value;
      const desired = options.slice(0, wanted);

      if (
        wanted &&
        activeNative &&
        !desired.some((option) => option.value === String(nativeId(activeNative)))
      ) {
        const activeItem = options.find(
          (option) => option.value === String(nativeId(activeNative)),
        );
        if (activeItem) {
          desired[desired.length - 1] = activeItem;
          desired.sort((left, right) => Number(left.value) - Number(right.value));
        }
      }
      if (!wanted) {
        for (const link of nativeExtra) {
          link.parentElement.removeAttribute(HIDDEN_ATTRIBUTE);
        }
      }

      const existing = extraItems(root);
      if (
        existing.map((item) => item.getAttribute(EXTRA_ATTRIBUTE)).join(",") !==
        desired.map((option) => option.value).join(",")
      ) {
        clearExtraItems(root);
        for (const option of desired) {
          const item = documentRef.createElement("li");
          item.setAttribute(EXTRA_ATTRIBUTE, option.value);
          item.className = "hidden-xs hidden-sm";
          const link = documentRef.createElement("a");
          link.href = "#";
          link.className = "num-nav";
          link.textContent = option.value;
          link.title = `Factura ${option.value}`;
          link.style.whiteSpace = "nowrap";
          link.addEventListener("click", (event) => {
            event.preventDefault();
            const liveSelect = documentRef.querySelector("#tabs #extra-tabs");
            if (!liveSelect) return;
            const nativeLink = nativeLinks(root).find(
              (candidate) => String(nativeId(candidate)) === option.value,
            );
            if (nativeLink) {
              nativeLink.click();
              schedule();
              return;
            }
            const liveOption = [...liveSelect.options].find(
              (candidate) => candidate.value === option.value,
            );
            if (!liveOption) return;
            const index = [...liveSelect.options].indexOf(liveOption);
            const menuItem = liveSelect.parentElement?.querySelector(
              `li[data-original-index="${index}"] a`,
            );
            if (menuItem) menuItem.click();
            else {
              liveSelect.value = option.value;
              liveSelect.dispatchEvent(new Event("change", { bubbles: true }));
            }
            schedule();
          });
          item.append(link);
          root.insertBefore(item, drop);
        }
      }

      for (const item of extraItems(root)) {
        const option = options.find(
          (candidate) => candidate.value === item.getAttribute(EXTRA_ATTRIBUTE),
        );
        const active = activeNative
          ? String(nativeId(activeNative)) === option?.value
          : !original.some((link) => link.parentElement.classList.contains("active")) &&
            selected === option?.value;
        item.classList.toggle("active", active);
        const hasProducts = Boolean(
          option &&
            (option.native?.parentElement.classList.contains("has-productos") ||
              /con productos/i.test(option.option?.parentElement?.label || "")),
        );
        item.classList.toggle("has-productos", hasProducts);
      }

      let added = extraItems(root);
      while (added.length) {
        const dropRect = drop.getBoundingClientRect();
        const liveActions = actions?.getBoundingClientRect();
        const liveStatus = indicator?.getBoundingClientRect();
        const edge =
          liveActions && liveActions.width > 0 && liveActions.left > rootRect.left
            ? Math.min(right, liveActions.left)
            : right;
        const collision =
          dropRect.right > edge - reserve ||
          (liveStatus &&
            liveStatus.width > 0 &&
            (liveStatus.right > edge - 4 ||
              liveStatus.top > rootRect.top + 25 ||
              liveStatus.left < dropRect.right - 2)) ||
          added.some(
            (item) =>
              item.getBoundingClientRect().top >
              rootRect.top +
                Math.max(12, (sample?.getBoundingClientRect().height || 40) / 2),
          );
        if (!collision) break;
        added.pop().remove();
      }
      for (const link of nativeExtra) {
        const represented = added.some(
          (item) =>
            item.getAttribute(EXTRA_ATTRIBUTE) === String(nativeId(link)),
        );
        link.parentElement.toggleAttribute(HIDDEN_ATTRIBUTE, represented);
      }
      status.shown = added.length;
      if (config.enabled && added.length < wanted) status.limit = added.length;
      return { ...status };
    }

    function schedule() {
      if (!started || pending) return;
      pending = true;
      const requestFrame =
        windowRef.requestAnimationFrame || ((callback) => callback(0));
      requestFrame(apply);
    }

    function setConfig(next) {
      config = normalizeConfig(next);
      schedule();
    }

    function handleMutation(records) {
      const relevant = records.some((record) => {
        const element =
          record.target.nodeType === 1
            ? record.target
            : record.target.parentElement;
        if (element?.closest?.(`[${EXTRA_ATTRIBUTE}]`)) return false;
        if (record.type === "childList") {
          const nodes = [...record.addedNodes, ...record.removedNodes];
          if (
            nodes.length &&
            nodes.every(
              (node) =>
                node.nodeType === 1 && node.hasAttribute(EXTRA_ATTRIBUTE),
            )
          ) {
            return false;
          }
        }
        return true;
      });
      if (relevant) schedule();
    }

    function start() {
      if (started) return;
      started = true;
      styleElement = documentRef.createElement("style");
      styleElement.textContent = `#tabs > li[${HIDDEN_ATTRIBUTE}], #tabs > li[${HIDDEN_ATTRIBUTE}].active {display:none!important;visibility:hidden!important;position:absolute!important;pointer-events:none!important}`;
      documentRef.head?.append(styleElement);
      const Observer =
        windowRef.MutationObserver || documentRef.defaultView?.MutationObserver;
      if (Observer && documentRef.body) {
        observer = new Observer(handleMutation);
        observer.observe(documentRef.body, {
          subtree: true,
          childList: true,
          attributes: true,
          attributeFilter: [
            "class",
            "style",
            "selected",
            "data-tab",
            "aria-selected",
          ],
          characterData: true,
        });
      }
      windowRef.addEventListener?.("resize", schedule);
      documentRef.addEventListener("change", schedule, true);
      schedule();
    }

    function stop() {
      if (!started) return;
      started = false;
      observer?.disconnect();
      observer = null;
      windowRef.removeEventListener?.("resize", schedule);
      documentRef.removeEventListener("change", schedule, true);
      const root = documentRef.querySelector("#tabs");
      if (root) {
        clearExtraItems(root);
        for (const item of root.children) item.removeAttribute(HIDDEN_ATTRIBUTE);
      }
      styleElement?.remove();
      styleElement = null;
      pending = false;
      status = { found: false, shown: 0, limit: 0 };
    }

    return {
      apply,
      getStatus: () => ({ ...status }),
      setConfig,
      start,
      stop,
    };
  }

  return {
    EXTRA_ATTRIBUTE,
    HIDDEN_ATTRIBUTE,
    MAX_EXTRA_TABS,
    createVisibleTabsController,
    normalizeConfig,
  };
});

(function initializeConticaTabsContent(root, factory) {
  const api = factory();
  root.TimeMasterHerramientasConticaTabsContent = api;
  if (typeof module === "object" && module.exports) {
    module.exports = api;
    return;
  }
  if (
    root.document &&
    root.chrome?.storage?.local &&
    root.TimeMasterHerramientasConticaTabs
  ) {
    api
      .createConticaTabsContentController({
        chromeApi: root.chrome,
        core: root.TimeMasterHerramientasConticaTabs,
        documentRef: root.document,
        windowRef: root,
      })
      .start();
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function buildContent() {
  "use strict";

  const ENABLED_KEY = "tmhConticaTabsVisiblesEnabled";
  const COUNT_KEY = "tmhConticaTabsVisiblesCount";

  function createConticaTabsContentController({
    chromeApi,
    core,
    documentRef,
    windowRef,
  }) {
    const visibleController = core.createVisibleTabsController({
      documentRef,
      windowRef,
    });
    const values = { enabled: false, count: 3 };
    const changedDuringInitialLoad = new Set();
    let started = false;
    let settingsLoaded = false;
    let lifecycleEpoch = 0;

    function normalizeCount(value, fallback) {
      return Number.isInteger(value) && value >= 0 && value <= 12
        ? value
        : fallback;
    }

    function applyValues() {
      visibleController.setConfig({ ...values });
    }

    function handleStorageChange(changes, areaName) {
      if (areaName !== "local") return;
      let changed = false;
      if (changes?.[ENABLED_KEY]) {
        if (!settingsLoaded) changedDuringInitialLoad.add(ENABLED_KEY);
        const next = changes[ENABLED_KEY].newValue;
        if (typeof next === "boolean") values.enabled = next;
        changed = true;
      }
      if (changes?.[COUNT_KEY]) {
        if (!settingsLoaded) changedDuringInitialLoad.add(COUNT_KEY);
        values.count = normalizeCount(changes[COUNT_KEY].newValue, values.count);
        changed = true;
      }
      if (changed) applyValues();
    }

    function handleMessage(message, _sender, reply) {
      if (message?.type !== "tmh-contica-tabs-status") return undefined;
      reply(visibleController.apply());
      return false;
    }

    function start() {
      if (started) return;
      started = true;
      settingsLoaded = false;
      changedDuringInitialLoad.clear();
      const currentEpoch = ++lifecycleEpoch;
      visibleController.start();
      chromeApi.storage.onChanged.addListener(handleStorageChange);
      chromeApi.runtime?.onMessage?.addListener(handleMessage);
      chromeApi.storage.local.get(
        { [ENABLED_KEY]: false, [COUNT_KEY]: 3 },
        (stored) => {
          if (!started || currentEpoch !== lifecycleEpoch) return;
          if (!changedDuringInitialLoad.has(ENABLED_KEY)) {
            values.enabled =
              typeof stored?.[ENABLED_KEY] === "boolean"
                ? stored[ENABLED_KEY]
                : false;
          }
          if (!changedDuringInitialLoad.has(COUNT_KEY)) {
            values.count = normalizeCount(stored?.[COUNT_KEY], 3);
          }
          settingsLoaded = true;
          changedDuringInitialLoad.clear();
          applyValues();
        },
      );
    }

    function destroy() {
      if (!started) return;
      chromeApi.storage.onChanged.removeListener(handleStorageChange);
      chromeApi.runtime?.onMessage?.removeListener(handleMessage);
      visibleController.stop();
      lifecycleEpoch += 1;
      changedDuringInitialLoad.clear();
      settingsLoaded = false;
      started = false;
    }

    return { destroy, start };
  }

  return { createConticaTabsContentController };
});
